import React from "react";
function Info() {
  return (
    <div className="note">
      <h1>JAVAScript and React.JS</h1>
      <p>A basic web dev React JS Boot camp</p>
    </div>
  );
}
export default Info;
